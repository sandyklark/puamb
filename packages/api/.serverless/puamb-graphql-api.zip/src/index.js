"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
require("reflect-metadata");
const typeorm_1 = require("typeorm");
const typedi_1 = require("typedi");
const type_graphql_1 = require("type-graphql");
const apollo_server_lambda_1 = require("apollo-server-lambda");
const User_1 = require("./entities/User");
const Post_1 = require("./entities/Post");
const Group_1 = require("./entities/Group");
const user_resolver_1 = require("./resolvers/user-resolver");
const DEFAULT_CONNECTION = 'default';
let db;
const createHandler = () => __awaiter(void 0, void 0, void 0, function* () {
    typeorm_1.useContainer(typedi_1.Container);
    const connectionManager = typeorm_1.getConnectionManager();
    if (connectionManager.has(DEFAULT_CONNECTION)) {
        db = connectionManager.get(DEFAULT_CONNECTION);
        if (!db.isConnected) {
            yield db.connect();
        }
    }
    else {
        db = yield typeorm_1.createConnection({
            type: 'mysql',
            database: process.env.DB_NAME,
            username: process.env.USERNAME,
            password: process.env.PASSWORD,
            port: parseInt(process.env.MYSQL_PORT),
            host: process.env.MYSQL_HOST,
            entities: [Group_1.Group, Post_1.Post, User_1.User],
            synchronize: true,
            logger: 'advanced-console',
            logging: 'all',
            dropSchema: true,
            cache: true
        });
    }
    const schema = yield type_graphql_1.buildSchema({
        resolvers: [user_resolver_1.UserResolver],
        container: typedi_1.Container
    });
    const server = new apollo_server_lambda_1.ApolloServer({ schema });
    return server.createHandler();
});
exports.handler = (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    createHandler().then((handler) => handler(event, context, callback));
};
//# sourceMappingURL=index.js.map