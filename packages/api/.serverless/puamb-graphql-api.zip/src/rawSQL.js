"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Require and initialize outside of your main handler
const serverless_mysql_1 = __importDefault(require("serverless-mysql"));
const connection = serverless_mysql_1.default({
    config: {
        host: process.env.MYSQL_HOST,
        database: process.env.DB_NAME,
        user: process.env.USERNAME,
        password: process.env.PASSWORD
    }
});
// Main handler function
exports.handler = (event, context) => __awaiter(void 0, void 0, void 0, function* () {
    // Run your query
    let results = yield connection.query(event.query);
    // Run clean up function
    yield connection.end();
    console.log("RESULT: ");
    console.log(results);
    // Return the results
    return {
        results
    };
});
//# sourceMappingURL=rawSQL.js.map